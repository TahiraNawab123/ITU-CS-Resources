#include"ComplexNumbers.h"
#include<iostream>
#include<fstream>

using namespace std;





void LoadComplex(ifstream& Rdr, ComplexNumber*& C, int& size)
{
	int real, imag;

	Rdr >> size;
	C = new ComplexNumber[size];

	for (int i = 0; i < size; i++)
	{
		Rdr >> real;
		Rdr >> imag;
		C[i].setReal(real);
		C[i].setImag(imag);
	}
}
void printAllComplex(ComplexNumber* C, int size)
{
	for (int i = 0; i < size; i++)
	{
		cout << i + 1 << ". ";
		C[i].printComplex();
        cout<<"\t";
	}
	cout << endl;
}
int main()
{
	int size;
	ComplexNumber* C;
	ifstream Rdr("complex.txt");
	LoadComplex(Rdr, C, size);

	ComplexNumber result;
	int i, j;
	char op;
	float answer;

	while (true)
	{
		printAllComplex(C, size);

		cout << "Enter the operation you want to perfom \n(+ for Addition)\t(- for Subtraction)\t\t(* for Multiplication)\n(/ for Division)"
			<< "\t(a for Additive Inverse)\t(m for Multiplicative Inverse)\n(c for Conjugate)\t(M for Modulus)\n";
		cin >> op;
		cout << "Enter your Complex Numbers: ";
		cin >> i >> j;
		switch (op)
		{

		case '+':
			result = C[i-1].AddComplex(C[j - 1]);
			cout << "Result: "; result.printComplex();
			break;
		case '-':
			result = C[i - 1].SubtractComplex(C[j - 1]);
			cout << "Result: "; result.printComplex();
			break;
		case '*':
			result = C[i - 1].MultiplyComplex( C[j - 1]);
			cout << "Result: "; result.printComplex();
			break;
		case '/':
			result = C[i - 1].DivideComplex( C[j - 1]);
			cout << "Result: "; result.printComplex();
			break;
		case 'a':
			result = C[i - 1].AdditiveInverse();
			cout << "Result: "; result.printComplex();
			break;
		case 'm':
			result = C[i - 1].MultiplicativeInverse();
			cout << "Result: "; result.printComplex();
			break;
		case 'c':
			result = C[i - 1].ConjugateComplex();
			cout << "Result: "; result.printComplex();
			break;
		case 'M':
			answer = C[i - 1].ModulusComplex();
			cout << "Answer: " << answer << endl;
			break;
		default:
			cout << "Invalid Option !" << endl;
		}

		char exit;
		cout << "\nDo you want to continue (y/n): ";
		cin >> exit;
		if (exit == 'n')
			break;
		else
			system("cls");
	}



	delete[]C;
    return 0;
}