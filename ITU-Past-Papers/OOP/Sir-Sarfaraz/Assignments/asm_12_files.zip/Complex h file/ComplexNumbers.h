#pragma once
#include<iostream>
#include<fstream>
#include<iomanip>
#include<cmath>

class ComplexNumber
{
    private:
        float asli;
        float nakli;
    public:
        ComplexNumber(float r=0,float i=0){
            asli=r;
            nakli=i;
        }
        void setReal(int r){
            asli=r;
        }
        void setImag(int i){
            nakli=i;
        }
        float getReal(){
            return asli;
        }
        float getImag(){
            return nakli;
        }
        void printComplex(){
            std::cout<<std::setw(2)<<asli<<" + "<<nakli<<"i";
        }
        ComplexNumber * Loader(int & n,std::ifstream & rdr){
            // Check if the file is open
            if (!rdr.is_open()) {
                std::cout << "Error: File not found\n";
                return nullptr;
            }
            rdr>>n;
            ComplexNumber * ptr=new ComplexNumber[n];
            for(int i=0;i<n;i++){
                rdr>>ptr[i].asli;
                rdr>>ptr[i].nakli;
            }
            return ptr;
        }
        ComplexNumber AddComplex(ComplexNumber B){
            ComplexNumber Ans(asli+B.asli,nakli+B.nakli);
            return Ans;
        }
        ComplexNumber SubtractComplex(ComplexNumber B){
            ComplexNumber Ans(asli-B.asli,nakli-B.nakli);
            return Ans;
        }
        ComplexNumber MultiplyComplex(ComplexNumber B){
            ComplexNumber Ans((asli*B.asli)-(nakli*B.nakli),(asli*B.nakli)+(nakli*B.asli));
            return Ans;
        }
        ComplexNumber DivideComplex(ComplexNumber B){
            ComplexNumber Ans(((asli*B.asli)+(nakli*B.nakli))/((B.asli*B.asli)+(B.nakli*B.nakli)),((nakli*B.asli)-(asli*B.nakli))/((B.asli*B.asli)+(B.nakli*B.nakli)));
            return Ans;
        }
        ComplexNumber MultiplicativeInverse(){
            ComplexNumber Ans((asli)/((asli*asli)+(nakli*nakli)),(nakli)/((asli*asli)+(nakli*nakli)));
            return Ans;
        }
        ComplexNumber AdditiveInverse(){
            ComplexNumber Ans(-1*asli,-1*nakli);
            return Ans;
        }
        float ModulusComplex(){
            return sqrt((asli*asli)+(nakli*nakli));
        }
        ComplexNumber ConjugateComplex(){
            ComplexNumber Ans(asli,-1*nakli);
            return Ans;
        }
};