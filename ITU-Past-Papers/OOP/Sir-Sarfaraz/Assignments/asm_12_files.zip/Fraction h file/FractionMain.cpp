#include"Fractions.h"
#include <iostream>
#include<fstream>

using namespace std;

void Loader(ifstream& Rdr, WholeFraction*& C, int& size)
{
	int who, num, den;

	Rdr >> size;
	C = new WholeFraction[size];

	for (int i = 0; i < size; i++)
	{
        Rdr >> who;
		Rdr >> num;
		Rdr >> den;
		C[i].set_whole(who);
        C[i].set_num(num);
		C[i].set_den(den);
	}
}

void printAllFraction(WholeFraction* C, int size)
{
	for (int i = 0; i < size; i++)
	{
		cout << i + 1 << ". ";
		C[i].print();
        cout<<"\t";
	}
	cout << endl;
}

int main(){
    int size;
	WholeFraction* C;
	ifstream Rdr("Fs.txt");
	Loader(Rdr, C, size);

	WholeFraction result;
	int i, j;
	char op;
	float answer;

	while (true)
	{
		printAllFraction(C, size);
		cout << "Enter the operation you want to perfom \n(+ for Addition)\t(- for Subtraction)\t\t(* for Multiplication)\n(/ for Division)"
			<< "\t(a for Additive Inverse)\t(m for Multiplicative Inverse)\n\n";
		cin >> op;
		cout << "Enter your Fraction Numbers: ";
		cin >> i >> j;
		switch (op)
		{
		case '+':
			result = C[i - 1].Add(C[j - 1]);
			cout << "Result: "; result.print();
			break;
		case '-':
			result = C[i - 1].Subtract(C[j - 1]);
			cout << "Result: "; result.print();
			break;
		case '*':
			result = C[i - 1].Mult(C[j - 1]);
			cout << "Result: "; result.print();
			break;
		case '/':
			result = C[i - 1].Div(C[j - 1]);
			cout << "Result: "; result.print();
			break;
		case 'a':
			result = C[i - 1].AddInv();
			cout << "Result: "; result.print();
			break;
		case 'm':
			result = C[i - 1].MultInv();
			cout << "Result: "; result.print();
			break;
		default:
			cout << "Invalid Option !" << endl;
		}

		char exit;
		cout << "\nDo you want to continue (y/n): ";
		cin >> exit;
		if (exit == 'n')
			break;
		else
			system("cls");
	}
	delete[]C;
    return 0;
}
    