#pragma once
#include<iostream>
#include<fstream>

class WholeFraction
{
    private:
        int w;//whole part
        int n;//numinater
        int d;//denominater

        int GCD(int A,int B){
            for(int d=std::min(A,B);true;d--){
                if(A%d==0 && B%d==0)
                    return d;
            }
            return 1;
        }
        int LCM(int A,int B){
            return A*B/GCD(A,B);
        }
        void MakeWhole(){
            w=n%d;
            n=n/d;
        }
        void MakeNormal(){
            n=d*w+n;
            w=0;
        }
    public:
        WholeFraction(int _w=0,int _n=0,int _d=1){//constructer
            this->w=_w;
            this->n=_n;
            if(_d!=0)
            this->d=_d;
            else
            this->d=1;
        }
        void set_whole(int _w){
            this->w=_w;
        }
        void set_num(int _n){
            this->n=_n;
        }
        void set_den(int _d){
            if(_d!=0)
            this->d=_d;
            else
            this->d=1;
        }
        int get_whole(){
            return this->w;
        }
        int get_num(){
            return this->n;
        }
        int get_den(){
            return this->d;
        }
        void print(){
            if(this->w!=0)
            std::cout<<"("<<w<<")"<<n<<"/"<<d;
            else
            std::cout<<n<<"/"<<d;
        }
        void Reduce(){
            int g=GCD(d,n);
            d=d/g;
            n=n/g;
        }
        WholeFraction* Loader(int & n,std::ifstream & rdr){
            // Check if the file is open
            if (!rdr.is_open()) {
                std::cout << "Error: File not found\n";
                return nullptr;
            }
            rdr>>n;
            WholeFraction* ptr=new WholeFraction[n];
            for(int i=0;i<n;i++){
                rdr>>ptr[i].w;
                rdr>>ptr[i].n;
                rdr>>ptr[i].d;
            }
            return ptr;
        }
        WholeFraction Add(WholeFraction B){
            this->MakeNormal();
            B.MakeNormal();
            WholeFraction Ans(0,((this->n*B.d)+(this->d*B.n)),this->d*B.d);
            Ans.Reduce();
            Ans.MakeWhole();
            return Ans;
        }
        WholeFraction Subtract(WholeFraction B){
            this->MakeNormal();
            B.MakeNormal();
            WholeFraction Ans(0,((this->n*B.d)-(this->d*B.n)),this->d*B.d);
            Ans.Reduce();
            Ans.MakeWhole();
            return Ans;
        }
        WholeFraction Mult(WholeFraction B){
            this->MakeNormal();
            B.MakeNormal();
            WholeFraction Ans(0,(this->n*B.n),(this->d*B.d));
            Ans.Reduce();
            Ans.MakeWhole();
            return Ans;
        }
        WholeFraction Div(WholeFraction B){
            this->MakeNormal();
            B.MakeNormal();
            WholeFraction Ans(0,(this->n*B.d),(this->n*B.d));
            Ans.Reduce();
            Ans.MakeWhole();
            return Ans;
        }
        WholeFraction MultInv(){
            this->MakeNormal();
            WholeFraction B(0,this->d,this->n);
            B.Reduce();
            B.MakeWhole();
            return B;
        }
        WholeFraction AddInv(){
            this->MakeNormal();
            WholeFraction B(0,-1*(this->n),this->d);
            B.Reduce();
            B.MakeWhole();
            return B;
        }
};